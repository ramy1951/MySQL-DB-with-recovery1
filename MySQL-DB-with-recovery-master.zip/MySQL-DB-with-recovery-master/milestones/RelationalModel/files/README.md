# Files that this folder must contain

1. databasemodel.mwb
2. databasemodel.sql
3. inserts.sql
4. tests.sql

